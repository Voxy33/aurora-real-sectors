// Secteur réel LFBD VERSION 4FLIGHT
// Par Raphaël PUCHEU

INSTRUCTIONS D'INSTALLATION


1 : Placer le dossier LFBD_APP_4FLT complet avec ce qu'il contient dans : Aurora/Sectorfiles/Include/FR\CUSTOM (si vous n'avez pas le dossier CUSTOM il vous faudras le créer)

2 : Placer le fichier LFBD_4FLT.isc dans : Aurora/Sectorfiles

3 : Placer le fichier 4FLIGHT_LFBD.clr dans : Aurora/Colorschemes

4 : Placer le fichier LFBD_4FLT.cpr dans : Aurora/Profiles

Pour lancer le secteur; ouvrez Aurora puis ouvrez le profil LFBD_4FLT.cpr

Libre a vous de modifier ce secteur en sachant qu'a chaque modification importante des AIRACS une nouvelle version seras mise en ligne.